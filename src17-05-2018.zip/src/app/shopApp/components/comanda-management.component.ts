import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'main-comanda',
  templateUrl: './../views/comanda.component.html',
  styleUrls: ['./../css/comanda.component.css']
})
export class ComandaManagement implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
