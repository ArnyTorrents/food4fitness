<?php
interface ControllerInterface
{
    public function doAction();    
}
?>
