<?php
interface EntityInterface
{
   
}
?>
